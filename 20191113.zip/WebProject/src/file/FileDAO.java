package file;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import common.JDBCTemplate;

public class FileDAO {
	
	
	public int upload(String fileName, String fileRealName) {
		String query = "INSERT INTO FILE1 VALUES(?, ?)";
		try {
			PreparedStatement pstmt = JDBCTemplate.getConnection().prepareStatement(query);
			pstmt.setString(1, fileName);
			pstmt.setString(2, fileRealName);
			return pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} 
		return -1;
	}
	
}
