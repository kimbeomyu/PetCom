package selfGuide.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import common.JDBCTemplate;
import selfGuide.model.vo.SelfGuide;

public class SelfGuideDao {
	
	public int insertSelfGuide(Connection conn, SelfGuide guideOne) {
		
		String query = "INSERT INTO SELF_GUIDE VALUES(DEFAULT, ?, ?, DEFAULT, DEFAULT, SEQ_SELF_NO.NEXTVAL, ?, ?, ?)";
		PreparedStatement pstmt = null;
		int result = 0;
		
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, guideOne.getWriterId());
			pstmt.setString(2, guideOne.getSelfContent());
			pstmt.setString(3, guideOne.getSelfTitle());
			pstmt.setString(4, guideOne.getPhotoOriginalFilename());
			pstmt.setString(5, guideOne.getPhotoRenameFilename());
			
			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JDBCTemplate.close(pstmt);
		}
		
		return result;
	}
}
