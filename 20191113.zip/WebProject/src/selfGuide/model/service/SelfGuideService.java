package selfGuide.model.service;

import java.sql.Connection;

import common.JDBCTemplate;
import selfGuide.model.dao.SelfGuideDao;
import selfGuide.model.vo.SelfGuide;

public class SelfGuideService {
	
	public int insertSelfGuide(SelfGuide guideOne) {
		
		Connection conn = JDBCTemplate.getConnection();
		int result = new SelfGuideDao().insertSelfGuide(conn, guideOne);
		
		// 데이터베이스에 변경사항 적용
		if(result>0) {
			JDBCTemplate.commit(conn);
		} else {
			JDBCTemplate.rollback(conn);
		}
		JDBCTemplate.close(conn);
		
		return result;
	}
}
