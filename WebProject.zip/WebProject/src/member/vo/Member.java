package member.vo;

public class Member {
	private String Member_ID;
	private String Member_Pwd;
	private String Member_Name;
	private String Member_Address;
	private String Member_Email;
	private String Member_Phone;
	
	public Member() {}
	
	public String getMember_ID() {
		return Member_ID;
	}
	public void setMember_ID(String member_ID) {
		Member_ID = member_ID;
	}
	public String getMember_Pwd() {
		return Member_Pwd;
	}
	public void setMember_Pwd(String member_Pwd) {
		Member_Pwd = member_Pwd;
	}
	public String getMember_Name() {
		return Member_Name;
	}
	public void setMember_Name(String member_Name) {
		Member_Name = member_Name;
	}
	public String getMember_Address() {
		return Member_Address;
	}
	public void setMember_Address(String member_Address) {
		Member_Address = member_Address;
	}
	public String getMember_Email() {
		return Member_Email;
	}
	public void setMember_Email(String member_Email) {
		Member_Email = member_Email;
	}
	public String getMember_Phone() {
		return Member_Phone;
	}
	public void setMember_Phone(String member_Phone) {
		Member_Phone = member_Phone;
	}
}
